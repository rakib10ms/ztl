import React, { useState } from 'react';
import '../footer/Footer.css';
// import logo from '../../Images/logo.png';
import ZT_LOGO_01 from '../../Images/ZT_LOGO_01.png';
import contact_img from '../../Images/contact_img.png';
import gmail_img from '../../Images/gmail_img.png';
import location_img from '../../Images/location_img.png';
import { Link } from "react-router-dom";
import Modal from 'react-modal';
import Swal from 'sweetalert2';
import axios from 'axios';

const Footer = () => {
    // // Consultation popup
    // const customStyles1 = {
    //     content: {
    //         marginTop: '70px',
    //         top: '35%',
    //         left: '25%',
    //         right: 'auto',
    //         bottom: 'auto',
    //         padding: '5px',
    //         marginRight: '-50%',
    //         transform: 'translate(-7%, -45%)',
    //         width: "55%",
    //         height: "530px",
    //         // background: "#ffffff",
    //     },
    //     overlay: { zIndex: 1000 }

    // };

    const [modalConsultationIsOpen, setModalConsultationIsOpen] = useState(false);
    function openModalConsultation(e) {
        e.preventDefault();
        // alert("mmm")
        setModalConsultationIsOpen(true);
    }
    function closeModalConsultation(e) {
        setModalConsultationIsOpen(false);

    }

    const [consultation1, setConsultation1] = useState({
        'name': '',
        'email': '',
        'phone': '',
        'message': '',
    })
    const handleChange = (e) => {
        setConsultation1({
            ...consultation1, [e.target.name]: e.target.value
        })

    }
    const handleSubmit = (e) => {
        e.preventDefault();
        // console.log('state data checking',consultation1)
        if (consultation1.name == '' || consultation1.phone == '' || consultation1.message == '') {
            Swal.fire("Please fill up all inputs", '', 'error')

        }
        else {

            axios.post(`/save-consultation`, consultation1).then(res => {
                if (res.data.status == 200) {
                    Swal.fire(res.data.message, '', 'success')

                    setConsultation1({
                        'name': '',
                        'email': '',
                        'phone': '',
                        'message': '',

                    })
                }
                else if (res.data.status == 400) {
                    setConsultation1({ ...consultation1, error_list: res.data.errors });

                }
            })
        }
    }


    return (
        <section>
            <div className="pt-0">
                <div className="consultation-bg">
                    <div className="container">
                        <div className="row g-3 pt-3">
                            <div className="col-md-8">
                                <h5 className="consultation__description">If you have any question or need to schedule for a consultation</h5>
                                <h4 className="consultation__call">Please Call Us Any Time at +8809617209581</h4>
                            </div>
                            <div className="col-md-4">
                                <Modal
                                    isOpen={modalConsultationIsOpen}
                                    onRequestClose={closeModalConsultation}
                                    // style={customStyles1}
                                    className="mymodal"
                                    overlayClassName="myoverlay"
                                    contentLabel="Example Modal"
                                >
                                    <div className='card-body modal__body'>
                                        <div className="row">
                                            <div className="col-12">
                                                <span className='float-end' style={{ fontSize: "20px", cursor: "pointer" }} onClick={closeModalConsultation}><i className="fa-solid fa-xmark close_btn"></i></span>
                                                <h6 className="header__consultation__text">Consultation</h6>
                                            </div>
                                        </div>
                                        <form className="pt-3" onSubmit={handleSubmit}>
                                            <div className="row mb-2">
                                                <div className="col-sm-12">
                                                    <label htmlFor="InputConsultationName" className="col-form-label col-form-label-sm d-block " >Name</label>
                                                    <input type="text" className="form-control form-control-sm " id="InputConsultationName" aria-describedby="emailHelp"
                                                        name="name" value={consultation1.name} onChange={handleChange}
                                                    // value={regularMedicineEight.indication}
                                                    // onChange={inputRegularMedicineChangeEight} 
                                                    />
                                                </div>
                                            </div>
                                            <div className="row mb-2">
                                                <div className="col-sm-12">
                                                    <label htmlFor="InputConsultationPhoneNumber" className="col-form-label col-form-label-sm d-block" >Phone Number</label>
                                                    <input type="text" className="form-control form-control-sm " id="InputConsultationPhoneNumber" aria-describedby="emailHelp"
                                                        name="phone" value={consultation1.phone} onChange={handleChange}
                                                    // value={regularMedicineEight.indication}
                                                    // onChange={inputRegularMedicineChangeEight} 
                                                    />
                                                </div>
                                            </div>
                                            <div className="row mb-2">
                                                <div className="col-sm-12">
                                                    <label htmlFor="InputConsultationEmail" className="col-form-label col-form-label-sm d-block" >Email</label>
                                                    <input type="email" className="form-control form-control-sm " id="InputConsultationEmail" aria-describedby="emailHelp"
                                                        name="email" value={consultation1.email} onChange={handleChange}
                                                    // value={regularMedicineEight.indication}
                                                    // onChange={inputRegularMedicineChangeEight} 
                                                    />
                                                </div>
                                            </div>
                                            <div className="row mb-2 d-flex">
                                                <div className="col-sm-12">
                                                    <label htmlFor="ConsultationMessegeFormControlTextarea1" className="col-form-label col-form-label-sm " >Messege</label>
                                                    <textarea className="form-control form-control-sm" placeholder="Write Here ..." id="ConsultationMessegeFormControlTextarea1" rows="4"
                                                        name="message" value={consultation1.message} onChange={handleChange}
                                                    ></textarea>
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="col-12">
                                                    <div className="text-start pt-4 mr-0">
                                                        <button type="submit" className="btn__apply"
                                                        // onClick={openModalConsultation}
                                                        >
                                                            <b>Submit</b>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </Modal>
                                <div className="consultation">
                                    <button type="button" className="form-control consultation-btn"
                                        onClick={openModalConsultation}
                                    >Consultation</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='footer_bg'>
                    <div className="container pt-5 mb-5">
                        <div className="row g-3 pt-3 mb-5">

                            <div className="col-md-3">
                                <h3 className="header_link_footer ps-md-5">Services</h3>
                                <div className="mt-0 ps-md-5">
                                    <a href="#" className="link_footer"><p>Web Development</p></a>
                                    <a href="#" className="link_footer"><p>Mobile Platform</p></a>
                                    <a href="#" className="link_footer"><p>Industry Revolutions (IR 4.0)</p></a>
                                    <a href="#" className="link_footer"><p>Business Management</p></a>
                                    <a href="#" className="link_footer"><p>Tech Consultancy Services</p></a>
                                    <a href="#" className="link_footer"><p>Digitization</p></a>
                                    <a href="#" className="link_footer"><p>UI/UX Design</p></a>
                                    <a href="#" className="link_footer"><p>IT Support Services</p></a>
                                    <a href="#" className="link_footer"><p>SCS</p></a>
                                    <a href="#" className="link_footer"><p>BPO</p></a>
                                    <a href="#" className="link_footer"><p>Training & Skill Development</p></a>
                                </div>
                            </div>
                            <div className="col-md-3">
                                <h3 className="header_link_footer ps-md-5">Technologies</h3>
                                <div className="mt-0 ps-md-5">
                                    <a href="#" className="link_footer"><p>PHP</p></a>
                                    <a href="#" className="link_footer"><p>Laravel</p></a>
                                    <a href="#" className="link_footer"><p>Flutter</p></a>
                                    <a href="#" className="link_footer"><p>React JS</p></a>
                                    <a href="#" className="link_footer"><p>Angular JS</p></a>
                                    <a href="#" className="link_footer"><p>Node JS</p></a>
                                    <a href="#" className="link_footer"><p>MySQL</p></a>
                                </div>
                            </div>
                            <div className="col-md-3">
                                <h3 className="header_link_footer ps-md-5">Our Product</h3>
                                <div className="mt-0 ps-md-5">
                                    <a href="#" className="link_footer"><p>Accounting Solutions</p></a>
                                    <a href="#" className="link_footer"><p>Inventory Solutions</p></a>
                                    <a href="#" className="link_footer"><p>ERP Solutions</p></a>
                                    <a href="#" className="link_footer"><p>CRM Solutions</p></a>
                                    <a href="#" className="link_footer"><p>HRM & Payroll Management</p></a>
                                    <a href="#" className="link_footer"><p>Hospital Management</p></a>
                                    <a href="#" className="link_footer"><p>Tours & Travel Management</p></a>
                                    <a href="#" className="link_footer"><p>Tours & Travel Management</p></a>
                                    <a href="#" className="link_footer"><p>Microfinance Software</p></a>
                                </div>
                            </div>
                            <div className="col-md-3">
                                <h3 className="header_link_footer ps-md-5">Company</h3>
                                <div className="mt-0 ps-md-5">
                                    <a href="#" className="link_footer"><p>About Us</p></a>
                                    <a href="#" className="link_footer"><p>Contact Us</p></a>
                                    <a href="#" className="link_footer"><p>Career</p></a>
                                    <a href="#" className="link_footer"><p>News</p></a>
                                    <a href="#" className="link_footer"><p>Blogs</p></a>
                                </div>
                            </div>
                        </div>

                        <hr className="footer-hr" />

                        <div className="row g-3 pt-5 ">
                            <div className="col-md-4 ">
                                <div className="row g-2">
                                    <div className="col-md-6">
                                        <div className="footer-img">
                                            <Link to="/" className="navbar-brand" >
                                                <img src={ZT_LOGO_01} className=" footer_bg img-fluid" style={{ width: '180px', height: '130px' }} alt="ZT_LOGO_01" border="0" />
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="footer-privacy-section">
                                            <p className="footer-privacy">Privacy Policy</p>
                                            <p className="footer-terms">Terms of Use</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4 ps-md-5">
                                <div className="footer_social_icon">
                                    <a href="#" className="fs-4 px-2 "><i className="text-muted fab fa-facebook-f"></i></a>
                                    <a href="#" className="fs-4 px-2 "><i className="text-muted fab fa-twitter"></i></a>
                                    <a href="#" className="fs-4 px-2 "><i className="text-muted fab fa-instagram"></i></a>
                                    <a href="#" className="fs-4 px-2 "><i className="text-muted fab fa-linkedin-in"></i></a>
                                    <a href="#" className="fs-4 px-2 "><i className="text-muted fab fa-pinterest-p"></i></a>
                                </div>
                            </div>
                            <div className="col-md-4 ps-md-5">
                                <div className="contact__foot">
                                    <ul className="list-unstyled pt-2">
                                        <li>
                                            <span><img src={contact_img} className=" img-fluid " style={{ width: '20', height: '25px' }} alt="RiverdaleSchool" border="0" /></span>
                                            <span className="ms-3">+8809617209581</span>
                                        </li>
                                        <li>
                                            <span><img src={gmail_img} className=" img-fluid " style={{ width: '20', height: '18px' }} alt="RiverdaleSchool" border="0" /></span>
                                            <span className="ms-3">info@zaimahtech.com</span>
                                        </li>
                                        <li>
                                            <span><img src={location_img} className=" img-fluid " style={{ width: '20', height: '25px' }} alt="RiverdaleSchool" border="0" /></span>
                                            <span className="ms-3">3 Dhakeswari Road, Lalbagh Dhaka</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>
                    <p className="footer_copyright">Copyright ©2017-2021 Zaimah Technologies Limited. All Rights Reserved.</p>
                </div>
            </div>
        </section>
    );
};

export default Footer;